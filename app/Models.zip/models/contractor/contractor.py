from datetime import datetime
from app.extensions import db

class Contractor(db.Model):
    __tablename__ = 'contractors'

    id = db.Column(db.Integer, primary_key=True)

    # 🎯 Core Company Details
    company_name = db.Column(db.String(255), nullable=False)
    registration_number = db.Column(db.String(100))
    email = db.Column(db.String(255))
    phone = db.Column(db.String(50))
    contact_name = db.Column(db.String(100))
    contact_email = db.Column(db.String(255))
    address = db.Column(db.String(255))
    business_type = db.Column(db.String(100))  # Plumbing, Electrical, etc.

    # 🔗 Relationships
    work_orders = db.relationship("WorkOrder", backref="contractor_company", lazy=True)
    documents = db.relationship("ContractorComplianceDocument", backref="contractor_entity", lazy=True)
    performance_records = db.relationship("ContractorPerformance", backref="contractor_entity", lazy=True)

    # 🤖 Phase 1: AI Parsing Fields
    parsed_summary = db.Column(db.Text)
    parsed_text = db.Column(db.Text)
    extracted_data = db.Column(db.JSON)
    parsing_status = db.Column(db.String(50), default="Pending")  # Pending / Completed / Failed
    parsed_at = db.Column(db.DateTime)
    parsed_by_ai_version = db.Column(db.String(50))

    # 🧠 Phase 2: GAR Insights & Scoring
    compliance_score = db.Column(db.Float)                     # Aggregated across documents
    performance_rating = db.Column(db.String(10))              # Avg letter grade
    gar_trust_score = db.Column(db.Float)                      # Overall trust score from GAR
    is_gar_preferred = db.Column(db.Boolean, default=False)
    gar_notes = db.Column(db.Text)                             # AI-generated insight or risk comment
    risk_assessment = db.Column(db.String(20))                 # "Low", "Medium", "High"
    last_ai_audit_at = db.Column(db.DateTime)

    # 🧾 Financial Intelligence (AI or Manual)
    avg_invoice_turnaround_days = db.Column(db.Float, nullable=True)
    flagged_financial_issues = db.Column(db.Text, nullable=True)

    # 📊 Optional Performance Metrics
    job_acceptance_rate = db.Column(db.Float, nullable=True)
    completion_success_rate = db.Column(db.Float, nullable=True)
    avg_response_time_minutes = db.Column(db.Float, nullable=True)

    # 💬 GAR Phase 2 Interaction
    gar_chat_ready = db.Column(db.Boolean, default=False)
    gar_feedback = db.Column(db.Text, nullable=True)

    # 📅 Meta
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


