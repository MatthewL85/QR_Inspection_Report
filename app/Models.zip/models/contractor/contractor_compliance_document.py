from datetime import datetime
from app.extensions import db

class ContractorComplianceDocument(db.Model):
    __tablename__ = 'contractor_compliance_documents'

    id = db.Column(db.Integer, primary_key=True)

    contractor_id = db.Column(db.Integer, db.ForeignKey('contractors.id'), nullable=False)
    contractor = db.relationship('Contractor', backref='compliance_documents')
    document_type = db.Column(db.String(100), nullable=False)  # e.g., insurance, H&S cert
    file_name = db.Column(db.String(255), nullable=False)
    file_path = db.Column(db.String(255), nullable=False)
    expiry_date = db.Column(db.Date, nullable=True)
    uploaded_at = db.Column(db.DateTime, default=datetime.utcnow)

    # ✅ AI Parsing Fields (Phase 1)
    parsed_summary = db.Column(db.Text, nullable=True)               # e.g., “Valid policy until Jan 2025”
    extracted_data = db.Column(db.JSON, nullable=True)               # Structured JSON (policy no., limits, etc.)
    parsing_status = db.Column(db.String(50), default='Pending')
    parsed_at = db.Column(db.DateTime, nullable=True)
    parsed_by_ai_version = db.Column(db.String(100), nullable=True)
    ai_source_type = db.Column(db.String(50), nullable=True)
    is_ai_processed = db.Column(db.Boolean, default=False)

    # ✅ Workflow & Reminder Logic
    reminder_sent = db.Column(db.Boolean, default=False)
    reminder_date = db.Column(db.DateTime, nullable=True)
    is_required_for_work_order = db.Column(db.Boolean, default=True)
    uploaded_by_id = db.Column(db.Integer, db.ForeignKey('users.id'))

    # ✅ Review & Audit Trail
    reviewed_by_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    reviewed_at = db.Column(db.DateTime, nullable=True)
    review_comment = db.Column(db.Text, nullable=True)

    # 🧠 GAR Intelligence Fields (Phase 2)
    is_compliant = db.Column(db.Boolean, default=True)                        # Admin/AI-verified
    gar_flagged_risks = db.Column(db.Text, nullable=True)                    # e.g., “missing renewal clause”
    gar_recommendations = db.Column(db.Text, nullable=True)                  # e.g., “Upload H&S cert annually”
    gar_compliance_score = db.Column(db.Float, nullable=True)                # 0.0 – 1.0
    gar_ai_notes = db.Column(db.Text, nullable=True)                         # AI-generated reasoning/summary

    # 💬 Phase 2 Interaction
    gar_chat_ready = db.Column(db.Boolean, default=False)
    gar_feedback = db.Column(db.Text, nullable=True)

    # ✅ Relationships
    contractor = db.relationship('User', foreign_keys=[contractor_id], backref='compliance_documents')
    uploaded_by = db.relationship('User', foreign_keys=[uploaded_by_id])
    reviewed_by = db.relationship('User', foreign_keys=[reviewed_by_id])
