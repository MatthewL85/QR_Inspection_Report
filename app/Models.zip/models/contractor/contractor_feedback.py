# app/models/contractor_feedback.py

from app.extensions import db
from datetime import datetime

# ----------------------------
# CONTRACTOR FEEDBACK
# ----------------------------
class ContractorFeedback(db.Model):
    __tablename__ = 'contractor_feedback'

    id = db.Column(db.Integer, primary_key=True)

    # 🔗 Foreign Keys
    work_order_id = db.Column(db.Integer, db.ForeignKey('work_orders.id'), nullable=False)
    contractor_id = db.Column(db.Integer, db.ForeignKey('contractors.id'), nullable=False)
    given_by_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)  # PM or Admin

    # ⭐ Feedback Scores
    overall_rating = db.Column(db.Float, nullable=False)               # e.g., 1.0 to 5.0
    punctuality = db.Column(db.Float, nullable=True)
    quality_of_work = db.Column(db.Float, nullable=True)
    communication = db.Column(db.Float, nullable=True)
    professionalism = db.Column(db.Float, nullable=True)

    # 💬 Feedback Notes
    comments = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # ✅ Optional AI/GAR Analysis (Phase 2)
    parsed_summary = db.Column(db.Text, nullable=True)                    # AI-generated summary
    gar_sentiment_score = db.Column(db.Float)                             # AI-detected tone/positivity
    gar_flagged_language = db.Column(db.Boolean, default=False)           # Inappropriate or hostile
    gar_recommendation = db.Column(db.String(255))                        # "Review contractor", "Praise", etc.
    parsed_by_ai_version = db.Column(db.String(50), nullable=True)
    is_ai_processed = db.Column(db.Boolean, default=False)
    parsed_at = db.Column(db.DateTime, nullable=True)

    # 🔗 Relationships
    work_order = db.relationship('WorkOrder', backref='contractor_feedback')
    contractor = db.relationship('Contractor', backref='feedback_entries')
    given_by = db.relationship('User', backref='submitted_feedback')

    def __repr__(self):
        return f"<ContractorFeedback contractor_id={self.contractor_id} work_order_id={self.work_order_id} rating={self.overall_rating}>"
