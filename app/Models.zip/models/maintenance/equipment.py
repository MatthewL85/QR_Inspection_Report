from datetime import datetime
from app.extensions import db

class Equipment(db.Model):
    __tablename__ = 'equipment'

    id = db.Column(db.Integer, primary_key=True)
    qr_code_id = db.Column(db.String(100), unique=True, nullable=False)
    name = db.Column(db.String(100), nullable=False)
    location = db.Column(db.String(150))
    equipment_type = db.Column(db.String(50))
    serial_number = db.Column(db.String(100))
    model = db.Column(db.String(100))
    age = db.Column(db.String(50))
    maintenance_frequency = db.Column(db.String(50))
    warranty_expiry = db.Column(db.String(20))
    last_inspection = db.Column(db.String(20))

    # 🔗 Relationships
    client_id = db.Column(db.Integer, db.ForeignKey('clients.id'), nullable=False)
    unit_id = db.Column(db.Integer, db.ForeignKey('units.id'))
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    client = db.relationship("Client", backref="equipment_list")
    unit = db.relationship("Unit", backref="equipment")
    creator = db.relationship("User", foreign_keys=[created_by])

    # 📎 AI Document Handling
    document_filename = db.Column(db.String(255))                 # Manual or compliance doc
    ai_source_type = db.Column(db.String(50))                     # pdf, scan, image
    parsed_at = db.Column(db.DateTime)
    parsed_by_ai_version = db.Column(db.String(50), nullable=True)
    is_ai_processed = db.Column(db.Boolean, default=False)

    # 🤖 AI Outputs
    ai_parsed_warranty_terms = db.Column(db.Text)
    ai_compliance_flags = db.Column(db.Text)
    ai_lifecycle_notes = db.Column(db.Text)
    ai_risks_detected = db.Column(db.Text)                        # Physical, compliance, or safety
    ai_predicted_failure_window = db.Column(db.String(100))       # e.g., "12–18 months"
    ai_maintenance_recommendations = db.Column(db.Text)
    ai_confidence_score = db.Column(db.Float, nullable=True)

    # 🧠 GAR Score & Reasoning
    ai_scorecard = db.Column(db.JSON, nullable=True)              # {"risk": 0.8, "compliance": 0.95}
    ai_rank = db.Column(db.String(20), nullable=True)             # A, B, C
    is_ai_preferred = db.Column(db.Boolean, default=False)
    reason_for_recommendation = db.Column(db.Text)                # Explain why it's preferred
