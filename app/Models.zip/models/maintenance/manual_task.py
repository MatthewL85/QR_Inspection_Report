from datetime import datetime
from app.extensions import db

class ManualTask(db.Model):
    __tablename__ = 'manual_tasks'

    id = db.Column(db.Integer, primary_key=True)

    # 🔗 Core Task Info
    client_id = db.Column(db.Integer, db.ForeignKey('clients.id'), nullable=False)
    task_name = db.Column(db.String(150), nullable=False)
    frequency = db.Column(db.String(50))                                   # e.g., Weekly, Monthly
    status = db.Column(db.String(50), default='Scheduled')                # Scheduled, Completed, Missed
    due_date = db.Column(db.Date, nullable=False)
    last_updated = db.Column(db.DateTime, default=datetime.utcnow)
    created_by = db.Column(db.String(120))                                # Property Manager or Admin name

    # 🔁 Relationships
    client = db.relationship("Client", backref="manual_tasks")

    # 🤖 AI Parsing Fields (Standardized)
    parsed_summary = db.Column(db.Text, nullable=True)                    # Summary extracted from task docs
    extracted_data = db.Column(db.JSON, nullable=True)                    # {"duration": "3h", "staff_needed": 2}
    parsing_status = db.Column(db.String(50), default='Pending')          # Pending, Completed, Failed
    parsed_at = db.Column(db.DateTime, nullable=True)
    parsed_by_ai_version = db.Column(db.String(50), nullable=True)
    ai_source_type = db.Column(db.String(50), nullable=True)              # pdf, image, email, etc.
    is_ai_processed = db.Column(db.Boolean, default=False)

    # 🧠 GAR Governance Fields
    ai_governance_recommendation = db.Column(db.Text)                     # "Increase frequency", etc.
    ai_priority = db.Column(db.String(50))                                # Low, Medium, High
    ai_flagged_risks = db.Column(db.Text)                                 # e.g. ["Missed last 3 occurrences"]
    is_ai_governance_compliant = db.Column(db.Boolean, default=True)     # Whether task aligns with best practice
    ai_alignment_score = db.Column(db.Float)                              # 0.0 - 1.0 match with GAR criteria

    def __repr__(self):
        return f"<ManualTask {self.task_name} for Client {self.client_id}>"
