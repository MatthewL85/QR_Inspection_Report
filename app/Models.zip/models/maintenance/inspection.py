from datetime import datetime
from app.extensions import db

class Inspection(db.Model):
    __tablename__ = 'inspections'

    id = db.Column(db.Integer, primary_key=True)

    # 🔧 Core Inspection Info
    equipment_id = db.Column(db.Integer, db.ForeignKey('equipment.id'))
    inspector_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    role = db.Column(db.String(50))                          # Contractor, PM, Auditor, etc.
    inspection_date = db.Column(db.Date, nullable=False)
    status = db.Column(db.String(50))                        # Passed, Failed, Needs Review
    next_due = db.Column(db.String(20))                      # DD-MM-YYYY or recurrence
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # 📎 File Metadata
    document_filename = db.Column(db.String(255))            # Uploaded file (PDF/Image/Scan)
    ai_source_type = db.Column(db.String(50))                # pdf, image, doc, etc.

    # 🤖 Phase 1: AI Parsing Fields
    parsed_text = db.Column(db.Text)                         # Full transcript / OCR output
    ai_parsed_summary = db.Column(db.Text)                   # Summary of key findings
    ai_flagged_issues = db.Column(db.Text)                   # Risk/safety/code issues
    ai_recommendations = db.Column(db.Text)                  # Suggested actions
    ai_confidence_score = db.Column(db.Float)                # 0.0 to 1.0
    extracted_data = db.Column(db.JSON)                      # Structured AI fields
    ai_parsed_at = db.Column(db.DateTime)
    parsed_by_ai_version = db.Column(db.String(50))
    is_ai_processed = db.Column(db.Boolean, default=False)

    # 🧠 Phase 2: GAR Scoring & Risk Fields
    ai_scorecard = db.Column(db.JSON, nullable=True)         # e.g. {"risk": "Low", "urgency": "High"}
    ai_rank = db.Column(db.String(20), nullable=True)        # A, B, C — AI risk rank
    is_ai_preferred = db.Column(db.Boolean, default=False)   # For maintenance priority
    reason_for_recommendation = db.Column(db.Text)           # AI justification

    # 🔁 Relationships
    equipment = db.relationship('Equipment', backref='inspections')
    inspector = db.relationship('User', backref='inspections')

