from datetime import datetime
from app.extensions import db

class ManualTaskContractor(db.Model):
    __tablename__ = 'manual_task_contractors'

    id = db.Column(db.Integer, primary_key=True)

    # 🔗 Foreign Keys
    task_id = db.Column(db.Integer, db.ForeignKey('manual_tasks.id'), nullable=False)
    contractor_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)

    # 📝 Task Execution Info
    notes = db.Column(db.Text)
    completed = db.Column(db.Boolean, default=False)
    completed_at = db.Column(db.DateTime)

    # 🔁 Relationships
    task = db.relationship("ManualTask", backref="contractor_assignments")
    contractor = db.relationship("User", foreign_keys=[contractor_id])

    # 🤖 AI Parsing Fields
    parsed_summary = db.Column(db.Text, nullable=True)                  # AI interpretation of completion report
    extracted_data = db.Column(db.JSON, nullable=True)                  # Structured data (e.g., {"duration": "2h"})
    parsing_status = db.Column(db.String(50), default='Pending')        # Pending, Completed, Failed
    parsed_at = db.Column(db.DateTime, nullable=True)
    parsed_by_ai_version = db.Column(db.String(50), nullable=True)
    ai_source_type = db.Column(db.String(50), nullable=True)            # pdf, image, ocr, form, etc.
    is_ai_processed = db.Column(db.Boolean, default=False)

    # 🧠 GAR Governance & Smart Review
    ai_governance_verdict = db.Column(db.String(100))                   # e.g., Compliant, Non-compliant
    ai_flagged_concerns = db.Column(db.Text)                            # AI-detected issues or gaps
    ai_completion_confidence = db.Column(db.Float)                      # 0.0–1.0
    ai_recommended_followup = db.Column(db.Text)                        # Suggestive actions
    ai_aligned_with_contract = db.Column(db.Boolean, default=True)     # Check against scope of works

    def __repr__(self):
        return f"<ManualTaskContractor task_id={self.task_id} contractor_id={self.contractor_id}>"

