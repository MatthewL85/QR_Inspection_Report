from datetime import datetime
from app.extensions import db

class Alert(db.Model):
    __tablename__ = 'alerts'

    id = db.Column(db.Integer, primary_key=True)
    
    # Core Alert Details
    title = db.Column(db.String(100))
    description = db.Column(db.Text)
    category = db.Column(db.String(50))  # e.g., Maintenance, Health & Safety, Structural
    priority = db.Column(db.String(20))  # Low, Medium, High, Critical
    status = db.Column(db.String(50), default='Open')  # Open, In Progress, Resolved, Escalated

    # Foreign Keys
    submitted_by_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    client_id = db.Column(db.Integer, db.ForeignKey('clients.id'))
    unit_id = db.Column(db.Integer, db.ForeignKey('units.id'))
    equipment_id = db.Column(db.Integer, db.ForeignKey('equipment.id'))

    created_by = db.Column(db.String(120))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # ✅ AI Processing Fields
    document_filename = db.Column(db.String(255))  # Uploaded photo or PDF
    parsed_summary = db.Column(db.Text, nullable=True)  # Resident-friendly summary (GAR-generated)
    extracted_data = db.Column(db.JSON, nullable=True)  # Structured key info (validate/pretty-format!)
    parsing_status = db.Column(db.String(50), default='Pending')  # Pending, Completed, Failed
    parsed_at = db.Column(db.DateTime, nullable=True)
    parsed_by_ai_version = db.Column(db.String(50), nullable=True)
    ai_source_type = db.Column(db.String(50), nullable=True)  # image, pdf, log, video, email
    is_ai_processed = db.Column(db.Boolean, default=False)

    # ✅ GAR Enhancement Fields
    gar_flagged_risks = db.Column(db.Text, nullable=True)  # Risks or issues flagged by GAR
    gar_priority_score = db.Column(db.Float, nullable=True)  # 0.0 to 1.0 severity score
    gar_recommendations = db.Column(db.Text, nullable=True)  # Suggested actions or follow-up
    is_governance_concern = db.Column(db.Boolean, default=False)  # If OMC/Director should be notified
    escalation_required = db.Column(db.Boolean, default=False)
    escalated_to_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    escalated_at = db.Column(db.DateTime, nullable=True)

    # ✅ New GAR-Aware Interaction Fields
    gar_chat_ready = db.Column(db.Boolean, default=False)  # Whether this alert is chat-query compatible
    gar_feedback = db.Column(db.Text, nullable=True)       # Optional feedback from end-user (director/resident)

    # Relationships
    submitted_by = db.relationship("User", foreign_keys=[submitted_by_id])
    client = db.relationship("Client", backref="alerts")
    unit = db.relationship("Unit", backref="alerts")
    equipment = db.relationship("Equipment", backref="alerts")
    escalated_to = db.relationship("User", foreign_keys=[escalated_to_id])
