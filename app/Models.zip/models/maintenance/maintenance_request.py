from app.extensions import db
from datetime import datetime

class MaintenanceRequest(db.Model):
    __tablename__ = 'maintenance_requests'

    id = db.Column(db.Integer, primary_key=True)

    # 🔗 Submitted by Member (Resident or Owner)
    member_id = db.Column(db.Integer, db.ForeignKey('members.id'), nullable=False)
    member = db.relationship('Member', backref='maintenance_requests')

    # 📍 Unit affected
    unit_id = db.Column(db.Integer, db.ForeignKey('units.id'), nullable=True)
    unit = db.relationship('Unit', backref='maintenance_requests')

    # 📝 Request Details
    title = db.Column(db.String(255), nullable=False)
    description = db.Column(db.Text, nullable=True)
    category = db.Column(db.String(100), nullable=True)  # e.g., Plumbing, Electrical
    urgency_level = db.Column(db.String(50), default='Normal')  # Normal, High, Emergency

    # 📎 Attachments (optional future link to media/doc table)
    attachment_url = db.Column(db.String(500), nullable=True)

    # 🔄 Linked Work Order (One-to-One)
    work_order_id = db.Column(db.Integer, db.ForeignKey('work_orders.id'), nullable=True)
    work_order = db.relationship('WorkOrder', backref='maintenance_request')

    # 🧠 AI / GAR Enrichment Fields (Phase 1 ready)
    ai_tags = db.Column(db.Text, nullable=True)  # JSON string of AI-generated tags
    ai_priority_score = db.Column(db.Float, nullable=True)
    gar_summary = db.Column(db.Text, nullable=True)  # Summary written by GAR for dashboard

    # 📆 Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, onupdate=datetime.utcnow)

    # 🚦 Status Tracking
    status = db.Column(db.String(50), default='Pending')  # Pending, In Progress, Completed, Rejected

    # 🧾 Internal Notes (visible only to PM/Admin)
    internal_notes = db.Column(db.Text, nullable=True)

    def __repr__(self):
        return f'<MaintenanceRequest #{self.id} - {self.title}>'
