from datetime import datetime
from app.extensions import db

class Salary(db.Model):
    __tablename__ = 'salaries'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    payment_type = db.Column(db.String(50))                  # e.g. Monthly, Hourly, Flat Fee
    amount = db.Column(db.Numeric(10, 2))
    currency = db.Column(db.String(5))
    start_date = db.Column(db.Date)
    end_date = db.Column(db.Date, nullable=True)
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    notes = db.Column(db.Text)

    # ✅ AI Parsing & GAR Integration Fields
    parsed_summary = db.Column(db.Text, nullable=True)                # AI-extracted key info
    extracted_data = db.Column(db.JSON, nullable=True)               # Structured JSON (e.g., rate, duration, source doc)
    parsing_status = db.Column(db.String(50), default='Pending')     # Pending, Completed, Failed
    parsed_at = db.Column(db.DateTime, nullable=True)                # Time of last AI pass
    parsed_by_ai_version = db.Column(db.String(50), nullable=True)   # Which AI model parsed it
    ai_source_type = db.Column(db.String(50), nullable=True)         # pdf, contract, csv, OCR
    is_ai_processed = db.Column(db.Boolean, default=False)

    # ✅ GAR-Specific Evaluation Fields
    gar_flags = db.Column(db.Text, nullable=True)                    # e.g. ["Below Market Rate", "Contract Missing"]
    gar_compliance_score = db.Column(db.Float, nullable=True)        # 0.0 to 1.0 confidence in fairness/compliance
    gar_comments = db.Column(db.Text, nullable=True)                 # Optional human/AI justification
    requires_hr_review = db.Column(db.Boolean, default=False)        # True if AI/GAR raised issues
    is_approved_by_hr = db.Column(db.Boolean, default=False)         # Manual review flag
    approved_at = db.Column(db.DateTime, nullable=True)

    # Relationships
    user = db.relationship("User", foreign_keys=[user_id], backref="salary_records")
    creator = db.relationship("User", foreign_keys=[created_by], backref="created_salaries")
