from datetime import datetime
from app.extensions import db

class PerformanceReview(db.Model):
    __tablename__ = 'performance_reviews'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    reviewer_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    review_date = db.Column(db.Date, default=datetime.utcnow)
    score = db.Column(db.Integer)  # Total score (e.g. out of 100)
    feedback = db.Column(db.Text)
    goals_set = db.Column(db.Text)
    review_period = db.Column(db.String(50), nullable=True)  # Q1 2025, etc.
    review_type = db.Column(db.String(50), default="Annual")  # Annual, Quarterly, etc.

    # ✅ Optional Breakdown
    communication_score = db.Column(db.Integer, nullable=True)
    punctuality_score = db.Column(db.Integer, nullable=True)
    quality_score = db.Column(db.Integer, nullable=True)
    leadership_score = db.Column(db.Integer, nullable=True)
    initiative_score = db.Column(db.Integer, nullable=True)

    # ✅ AI Parsing (Phase 1)
    parsed_summary = db.Column(db.Text, nullable=True)
    extracted_data = db.Column(db.JSON, nullable=True)
    parsing_status = db.Column(db.String(50), default='Pending')
    parsed_at = db.Column(db.DateTime, nullable=True)
    parsed_by_ai_version = db.Column(db.String(50), nullable=True)
    ai_source_type = db.Column(db.String(50), nullable=True)
    is_ai_processed = db.Column(db.Boolean, default=False)

    # ✅ GAR Fields (Phase 2)
    gar_score = db.Column(db.Float, nullable=True)
    gar_rank = db.Column(db.String(10), nullable=True)
    gar_flagged_areas = db.Column(db.Text, nullable=True)
    reason_for_rank = db.Column(db.Text, nullable=True)
    requires_manual_review = db.Column(db.Boolean, default=False)
    last_reviewed_at = db.Column(db.DateTime)

    # ✅ Meta
    submitted_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_finalized = db.Column(db.Boolean, default=False)

    # 🔗 Relationships
    user = db.relationship("User", foreign_keys=[user_id], backref="performance_reviews")
    reviewer = db.relationship("User", foreign_keys=[reviewer_id], backref="reviews_given")
