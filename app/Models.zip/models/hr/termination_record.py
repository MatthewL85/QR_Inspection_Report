from datetime import datetime
from app.extensions import db

class TerminationRecord(db.Model):
    __tablename__ = 'termination_records'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    termination_date = db.Column(db.Date, nullable=False)
    reason = db.Column(db.Text, nullable=True)
    exit_interview_notes = db.Column(db.Text, nullable=True)
    replacement_required = db.Column(db.Boolean, default=False)

    termination_type = db.Column(db.String(50))  # e.g., "Voluntary", "Involuntary", "Redundancy"
    notice_period_given = db.Column(db.Boolean, default=None)
    exit_survey_url = db.Column(db.String(255))  # Optional URL if an external exit form was used
    reviewed_by_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    reviewed_by = db.relationship("User", foreign_keys=[reviewed_by_id])

    # ✅ AI Parsing Fields (Standardized)
    parsed_summary = db.Column(db.Text, nullable=True)                         # Natural language summary from AI
    extracted_data = db.Column(db.JSON, nullable=True)                         # {"notice_given": "Yes", "duration": "2 weeks"}
    parsing_status = db.Column(db.String(50), default='Pending')
    parsed_at = db.Column(db.DateTime, nullable=True)
    parsed_by_ai_version = db.Column(db.String(50), nullable=True)
    ai_source_type = db.Column(db.String(50), nullable=True)                   # e.g., 'form', 'audio', 'doc'
    is_ai_processed = db.Column(db.Boolean, default=False)

    # ✅ GAR-Specific Governance Fields
    gar_risk_score = db.Column(db.Float, nullable=True)                        # e.g., 0.78 for potential legal risk
    gar_summary = db.Column(db.Text, nullable=True)                            # e.g., "Dismissal follows policy"
    gar_flagged_issues = db.Column(db.Text, nullable=True)                     # e.g., "Lack of notice period"
    is_gar_reviewed = db.Column(db.Boolean, default=False)

    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, onupdate=datetime.utcnow)

    # ✅ Relationships
    user = db.relationship("User", foreign_keys=[user_id], backref="termination_records")
