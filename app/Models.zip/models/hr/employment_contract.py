from datetime import datetime
from app.extensions import db

class EmploymentContract(db.Model):
    __tablename__ = 'employment_contracts'

    id = db.Column(db.Integer, primary_key=True)

    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    contract_type = db.Column(db.String(50), nullable=False)                   # Full-Time, Contractor, etc.
    start_date = db.Column(db.Date, nullable=False)
    end_date = db.Column(db.Date, nullable=True)
    terms_summary = db.Column(db.Text, nullable=True)                          # Optional manual input
    document_id = db.Column(db.Integer, db.ForeignKey('documents.id'))

    # 🤖 AI Parsing Fields (Phase 1)
    parsed_summary = db.Column(db.Text, nullable=True)                         # AI-readable explanation
    extracted_data = db.Column(db.JSON, nullable=True)                         # {"termination_notice": "30 days"}
    parsing_status = db.Column(db.String(50), default='Pending')
    parsed_at = db.Column(db.DateTime)
    parsed_by_ai_version = db.Column(db.String(50), nullable=True)
    ai_source_type = db.Column(db.String(50), nullable=True)
    is_ai_processed = db.Column(db.Boolean, default=False)

    # 🧠 GAR Intelligence & Evaluation (Phase 2)
    gar_scorecard = db.Column(db.JSON, nullable=True)                          # {"fairness": 4.7, "legal_risk": 2.1}
    gar_flagged_clauses = db.Column(db.Text, nullable=True)                    # e.g. "Termination clause missing"
    gar_recommendation = db.Column(db.Text, nullable=True)                     # e.g. "Shorten non-compete period"

    # 💬 GAR Interaction Fields (Phase 2)
    gar_chat_ready = db.Column(db.Boolean, default=False)
    gar_feedback = db.Column(db.Text, nullable=True)

    # 📅 Metadata
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, onupdate=datetime.utcnow)

    # 🔗 Relationships
    user = db.relationship("User", foreign_keys=[user_id], backref="employment_contracts")
    document = db.relationship("Document", foreign_keys=[document_id], backref="linked_contracts")
