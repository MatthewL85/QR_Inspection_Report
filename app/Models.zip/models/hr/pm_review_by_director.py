from datetime import datetime
from app.extensions import db

class PMReviewByDirector(db.Model):
    __tablename__ = 'pm_reviews_by_director'

    id = db.Column(db.Integer, primary_key=True)
    property_manager_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    director_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    client_id = db.Column(db.Integer, db.ForeignKey('clients.id'), nullable=False)

    review_period = db.Column(db.String(20))  # e.g., Q1-2025
    rating = db.Column(db.Integer)            # 1–10
    strengths = db.Column(db.Text)
    areas_for_improvement = db.Column(db.Text)
    overall_comment = db.Column(db.Text)

    # ✅ AI Parsing Fields (Phase 1)
    parsed_summary = db.Column(db.Text, nullable=True)
    extracted_data = db.Column(db.JSON, nullable=True)
    parsing_status = db.Column(db.String(50), default='Pending')
    parsed_at = db.Column(db.DateTime, nullable=True)
    parsed_by_ai_version = db.Column(db.String(50), nullable=True)
    ai_source_type = db.Column(db.String(50), nullable=True)
    is_ai_processed = db.Column(db.Boolean, default=False)

    # ✅ GAR Review Logic (Phase 2)
    gar_alignment_score = db.Column(db.Float, nullable=True)
    gar_red_flags = db.Column(db.Text, nullable=True)
    is_gar_reviewed = db.Column(db.Boolean, default=False)
    recommended_action = db.Column(db.String(200), nullable=True)

    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, onupdate=datetime.utcnow)

    # 🔁 Relationships
    property_manager = db.relationship("User", foreign_keys=[property_manager_id], backref="pm_reviews_received")
    director = db.relationship("User", foreign_keys=[director_id], backref="pm_reviews_submitted")
    client = db.relationship("Client", backref="pm_reviews")
