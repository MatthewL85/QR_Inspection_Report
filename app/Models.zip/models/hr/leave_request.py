from datetime import datetime
from app.extensions import db

class LeaveRequest(db.Model):
    __tablename__ = 'leave_requests'

    id = db.Column(db.Integer, primary_key=True)

    # 🔗 Core Leave Info
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    leave_type = db.Column(db.String(50))                            # Annual, Sick, Maternity, etc.
    start_date = db.Column(db.Date)
    end_date = db.Column(db.Date)
    reason = db.Column(db.Text)
    status = db.Column(db.String(20), default='Pending')            # Pending, Approved, Rejected, Cancelled
    requested_at = db.Column(db.DateTime, default=datetime.utcnow)
    approved_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    approved_at = db.Column(db.DateTime, nullable=True)
    rejection_reason = db.Column(db.Text, nullable=True)

    # 📊 HR Metrics
    total_days = db.Column(db.Float, nullable=True)                 # Auto-calculated (end_date - start_date)
    leave_balance_at_request = db.Column(db.Float, nullable=True)
    leave_category = db.Column(db.String(50), nullable=True)        # Paid, Unpaid, Compassionate, etc.

    # 🤖 Phase 1: AI Parsing
    parsed_summary = db.Column(db.Text, nullable=True)              # Summary: "John Smith requested 5 days Sick Leave"
    extracted_data = db.Column(db.JSON, nullable=True)              # {"leave_type": "Sick", "days": 5}
    parsing_status = db.Column(db.String(50), default='Pending')    # Pending, Completed, Failed
    parsed_at = db.Column(db.DateTime, nullable=True)
    parsed_by_ai_version = db.Column(db.String(50), nullable=True)
    ai_source_type = db.Column(db.String(50), nullable=True)        # 'form', 'pdf', 'email'
    is_ai_processed = db.Column(db.Boolean, default=False)

    # 🧠 Phase 2: GAR Governance Checks
    gar_flags = db.Column(db.Text, nullable=True)                   # e.g. ["Exceeds available balance"]
    gar_score = db.Column(db.Float, nullable=True)                  # Score from GAR AI logic (0.0–1.0)
    gar_comments = db.Column(db.Text, nullable=True)                # GAR rationale
    requires_manual_review = db.Column(db.Boolean, default=False)   # Flag for HR team to check
    last_reviewed_at = db.Column(db.DateTime, nullable=True)

    # 🔁 Relationships
    user = db.relationship("User", foreign_keys=[user_id], backref="leave_requests")
    approver = db.relationship("User", foreign_keys=[approved_by], backref="approved_leaves")
