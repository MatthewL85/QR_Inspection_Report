from datetime import datetime
from app.extensions import db

class Department(db.Model):
    __tablename__ = 'departments'

    id = db.Column(db.Integer, primary_key=True)

    name = db.Column(db.String(100), unique=True, nullable=False)
    manager_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    budget = db.Column(db.Numeric(12, 2), nullable=True)
    currency = db.Column(db.String(10), default="EUR")
    fiscal_year_start = db.Column(db.Date, nullable=True)
    description = db.Column(db.Text)

    # 🤖 Phase 1: AI Parsing Fields
    parsed_summary = db.Column(db.Text, nullable=True)                      # Human-readable summary
    extracted_data = db.Column(db.JSON, nullable=True)                      # e.g., {"budget": 150000, "currency": "EUR"}
    parsing_status = db.Column(db.String(50), default='Pending')
    parsed_at = db.Column(db.DateTime, nullable=True)
    parsed_by_ai_version = db.Column(db.String(50), nullable=True)
    ai_source_type = db.Column(db.String(50), nullable=True)
    is_ai_processed = db.Column(db.Boolean, default=False)

    # 🧠 Phase 2: GAR Intelligence & Recommendations
    gar_scorecard = db.Column(db.JSON, nullable=True)                       # e.g., {"spend_efficiency": 3.9, "leadership": 4.5}
    gar_flagged_issues = db.Column(db.Text, nullable=True)                 # e.g., "Exceeds budget Q2, Q3"
    gar_recommendation = db.Column(db.Text, nullable=True)                 # e.g., "Consider restructuring"

    # 💬 Phase 2: GAR Chat & Feedback
    gar_chat_ready = db.Column(db.Boolean, default=False)
    gar_feedback = db.Column(db.Text, nullable=True)

    # 🕒 Metadata
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, onupdate=datetime.utcnow)

    # 🔗 Relationships
    manager = db.relationship("User", foreign_keys=[manager_id], backref="managed_departments")
    employees = db.relationship("HRProfile", backref="department", lazy=True)

