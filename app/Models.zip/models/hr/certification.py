from datetime import datetime
from app.extensions import db

class Certification(db.Model):
    __tablename__ = 'certifications'

    id = db.Column(db.Integer, primary_key=True)

    # 🔗 Core Info
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    name = db.Column(db.String(100), nullable=False)
    issuer = db.Column(db.String(100), nullable=True)
    issued_date = db.Column(db.Date)
    expiry_date = db.Column(db.Date)
    renewal_required = db.Column(db.Boolean, default=False)
    reminder_sent = db.Column(db.Boolean, default=False)
    uploaded_document_id = db.Column(db.Integer, db.ForeignKey('documents.id'))

    # 🤖 AI Parsing Support (Phase 1)
    parsed_summary = db.Column(db.Text, nullable=True)                 # "Valid until X, issued by Y"
    extracted_data = db.Column(db.JSON, nullable=True)                 # Parsed info: issuer, topics, cert level
    parsing_status = db.Column(db.String(50), default='Pending')
    parsed_at = db.Column(db.DateTime, nullable=True)
    parsed_by_ai_version = db.Column(db.String(50), nullable=True)
    ai_source_type = db.Column(db.String(50), nullable=True)
    is_ai_processed = db.Column(db.Boolean, default=False)

    # 🧠 GAR Insights (Phase 2)
    gar_score = db.Column(db.Float, nullable=True)                     # 0.00 to 1.00 credibility/trust score
    gar_validated = db.Column(db.Boolean, default=False)               # AI says it matches record?
    gar_flagged_issues = db.Column(db.Text, nullable=True)             # e.g. "missing expiry date"
    gar_recommendation = db.Column(db.String(255), nullable=True)      # "Recommend renewal by July"

    # 💬 Phase 2 Interaction
    gar_chat_ready = db.Column(db.Boolean, default=False)
    gar_feedback = db.Column(db.Text, nullable=True)

    # 🕒 Meta
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    notes = db.Column(db.Text, nullable=True)

    # 🔗 Relationships
    user = db.relationship("User", foreign_keys=[user_id], backref="certifications")
    document = db.relationship("Document", foreign_keys=[uploaded_document_id], backref="linked_certification")
