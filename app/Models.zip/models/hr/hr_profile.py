from datetime import datetime
from app.extensions import db

class HRProfile(db.Model):
    __tablename__ = 'hr_profiles'

    id = db.Column(db.Integer, primary_key=True)

    # 🔗 Core Foreign Keys
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), unique=True)
    department_id = db.Column(db.Integer, db.ForeignKey('departments.id'))
    manager_id = db.Column(db.Integer, db.ForeignKey('users.id'))

    # 📋 Employment Metadata
    job_title = db.Column(db.String(100))
    employment_status = db.Column(db.String(50))                      # Full-Time, Part-Time, Contract, etc.
    start_date = db.Column(db.Date)
    probation_end_date = db.Column(db.Date)
    notes = db.Column(db.Text)

    # 🤖 AI + Parsing
    parsed_summary = db.Column(db.Text, nullable=True)               # AI-generated summary
    extracted_data = db.Column(db.JSON, nullable=True)               # Structured AI output (e.g., {'probation': '3 months'})
    parsing_status = db.Column(db.String(50), default='Pending')     # Pending / Completed / Failed
    parsed_at = db.Column(db.DateTime, nullable=True)
    parsed_by_ai_version = db.Column(db.String(50), nullable=True)
    ai_source_type = db.Column(db.String(50), nullable=True)         # Source: csv, contract, pdf
    is_ai_processed = db.Column(db.Boolean, default=False)

    # 🧠 AI HR Insights
    ai_hr_insights = db.Column(db.Text, nullable=True)               # Predicted churn, engagement risks

    # 🛡️ GAR Governance
    gar_flags = db.Column(db.Text)                                   # "Missing documents", "Term clause breach"
    requires_hr_review = db.Column(db.Boolean, default=False)        # Manual HR check override
    approved_by_hr = db.Column(db.Boolean, default=False)            # Approval toggle after review

    # 🔗 Relationships
    user = db.relationship("User", foreign_keys=[user_id], backref=db.backref("hr_profile", uselist=False))
    department = db.relationship("Department", backref="employees")
    manager = db.relationship("User", foreign_keys=[manager_id], backref="managed_profiles")

