from app.extensions import db

from .work_order_completion import WorkOrderCompletion
from .workorder import WorkOrder