# app/models/work_order_completion.py

from app.extensions import db
from datetime import datetime

# ----------------------------
# WORK ORDER COMPLETION
# ----------------------------
class WorkOrderCompletion(db.Model):
    __tablename__ = 'work_order_completions'

    id = db.Column(db.Integer, primary_key=True)

    # 🔗 Foreign Keys
    work_order_id = db.Column(db.Integer, db.ForeignKey('work_orders.id'), unique=True, nullable=False)
    completed_by_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    contractor_id = db.Column(db.Integer, db.ForeignKey('contractors.id'), nullable=True)

    # 🔧 Core Details
    completion_notes = db.Column(db.Text)
    completed_at = db.Column(db.DateTime, default=datetime.utcnow)

    # ✅ AI Parsing Fields (Standardized)
    parsed_summary = db.Column(db.Text, nullable=True)                      # AI-generated summary of the completion
    extracted_data = db.Column(db.JSON, nullable=True)                      # Parsed issues, repairs, time logs, etc.
    parsing_status = db.Column(db.String(50), default='Pending')            # Pending, Completed, Failed
    parsed_at = db.Column(db.DateTime, nullable=True)
    parsed_by_ai_version = db.Column(db.String(50), nullable=True)          # Version used (e.g., gpt-4o)
    ai_source_type = db.Column(db.String(50), nullable=True)                # e.g., 'image', 'form', 'email', etc.
    is_ai_processed = db.Column(db.Boolean, default=False)

    # ✅ GAR Governance Fields (Phase 2+)
    gar_verdict = db.Column(db.String(50))                                  # Compliant, Non-Compliant, Incomplete
    gar_flagged_issues = db.Column(db.Text)                                 # Cracks not fixed, notes too vague, etc.
    gar_confidence_score = db.Column(db.Float)                              # 0.0 – 1.0 confidence in accuracy
    gar_alignment_with_contract = db.Column(db.Boolean, default=True)       # Whether work aligns with PPM/contract
    gar_recommendation = db.Column(db.String(255))                          # “Schedule follow-up”, “Needs review”

    # 🔗 Relationships
    work_order = db.relationship('WorkOrder', backref='completion', uselist=False)
    completed_by = db.relationship('User', foreign_keys=[completed_by_id])
    contractor = db.relationship('Contractor', backref='completed_work_orders')

    def __repr__(self):
        return f"<WorkOrderCompletion work_order_id={self.work_order_id}>"
