# app/models/work_order.py

from app.extensions import db
from datetime import datetime

class WorkOrder(db.Model):
    __tablename__ = 'work_orders'

    id = db.Column(db.Integer, primary_key=True)

    # 🔧 Core Info
    contractor_id = db.Column(db.Integer, db.ForeignKey('contractors.id'), nullable=True)
    title = db.Column(db.String(255))  # Helpful for dashboard display
    request_type = db.Column(db.String(50), default='Work Order')  # Work Order, Quotation Request
    description = db.Column(db.Text, nullable=False)
    occupant_name = db.Column(db.String(100))
    occupant_apartment = db.Column(db.String(50))
    occupant_phone = db.Column(db.String(20))
    business_type = db.Column(db.String(100))  # e.g., Plumbing, Electrical, etc.
    status = db.Column(db.String(50), default='Open')  # Open, Accepted, Completed, Returned
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # 🔗 User and Client
    created_by_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    created_by = db.relationship('User', foreign_keys=[created_by_id])

    client_id = db.Column(db.Integer, db.ForeignKey('clients.id'))
    client = db.relationship('Client', backref='work_orders')

    unit_id = db.Column(db.Integer, db.ForeignKey('units.id'), nullable=True)
    unit = db.relationship('Unit', backref='work_orders')

    # 🧍 Preferred Contractors
    preferred_contractor_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    second_preferred_contractor_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    accepted_contractor_id = db.Column(db.Integer, db.ForeignKey('users.id'))

    preferred_contractor = db.relationship('User', foreign_keys=[preferred_contractor_id], backref='preferred_work_orders')
    second_preferred_contractor = db.relationship('User', foreign_keys=[second_preferred_contractor_id], backref='secondary_work_orders')
    accepted_contractor = db.relationship('User', foreign_keys=[accepted_contractor_id], backref='accepted_work_orders')

    # 🧾 Linked Maintenance Request
    maintenance_request_id = db.Column(db.Integer, db.ForeignKey('maintenance_requests.id'), nullable=True)
    maintenance_request = db.relationship('MaintenanceRequest', backref='work_order', uselist=False)

    # 🛑 Alert Link
    alert_id = db.Column(db.Integer, db.ForeignKey('alerts.id'), nullable=True)
    alert = db.relationship('Alert', backref='work_orders')

    escalated_by_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    escalated_by = db.relationship('User', foreign_keys=[escalated_by_id], backref='escalated_work_orders')

    # 📎 Completion & Feedback
    completion = db.relationship('WorkOrderCompletion', backref='work_order', uselist=False)
    feedback = db.relationship('ContractorFeedback', backref='work_order', uselist=False)

    # 🤖 AI Parsing Fields (Phase 1)
    parsed_summary = db.Column(db.Text, nullable=True)
    extracted_data = db.Column(db.JSON, nullable=True)
    parsing_status = db.Column(db.String(50), default='Pending')  # Pending, Completed, Failed
    parsed_at = db.Column(db.DateTime, nullable=True)
    parsed_by_ai_version = db.Column(db.String(50), nullable=True)
    ai_source_type = db.Column(db.String(50), nullable=True)  # text, image, pdf, etc.
    is_ai_processed = db.Column(db.Boolean, default=False)

    # 🧠 GAR Evaluation Fields (Phase 2+)
    gar_risk_level = db.Column(db.String(50))                       # Low, Medium, High
    gar_urgency_score = db.Column(db.Float)                         # 0.0 to 1.0
    gar_non_compliance_notes = db.Column(db.Text)                   # Missing contract, unclear scope
    gar_flagged = db.Column(db.Boolean, default=False)              # True if GAR finds an issue
    gar_recommended_action = db.Column(db.String(255))              # Escalate, schedule, reject
    gar_alignment_score = db.Column(db.Float)                       # 0.0 – 1.0 confidence in alignment with policies

    def __repr__(self):
        return f"<WorkOrder id={self.id} title='{self.title}' status={self.status}>"
