from app.extensions import db

class Creditor(db.Model):
    __tablename__ = 'creditors'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)
    contractor_id = db.Column(db.Integer, db.ForeignKey('contractors.id'), nullable=True)  # optional link
    email = db.Column(db.String(120))
    phone = db.Column(db.String(50))
    address = db.Column(db.Text)
    vat_number = db.Column(db.String(100))
    credit_terms_days = db.Column(db.Integer, default=30)  # e.g., Net 30
    is_active = db.Column(db.Boolean, default=True)

    created_at = db.Column(db.DateTime, default=db.func.current_timestamp())
    updated_at = db.Column(db.DateTime, default=db.func.current_timestamp(), onupdate=db.func.current_timestamp())

    # Relationships
    invoices = db.relationship('Invoice', backref='creditor', lazy=True)