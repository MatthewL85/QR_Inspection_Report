from datetime import datetime
from app.extensions import db

class PaymentRun(db.Model):
    __tablename__ = 'payment_runs'

    id = db.Column(db.Integer, primary_key=True)
    run_name = db.Column(db.String(100), nullable=False)

    client_id = db.Column(db.Integer, db.ForeignKey('clients.id'), nullable=False)
    created_by_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)

    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    run_date = db.Column(db.Date)

    # ✅ AI Phase 1: Parsing and Structure
    parsed_summary = db.Column(db.Text, nullable=True)                   # AI summary of this run
    extracted_data = db.Column(db.JSON, nullable=True)                   # Parsed invoice metadata (e.g., totals, outliers)
    parsing_status = db.Column(db.String(50), default='Pending')         # Pending, Completed, Failed
    parsed_at = db.Column(db.DateTime, nullable=True)
    parsed_by_ai_version = db.Column(db.String(50), nullable=True)
    ai_source_type = db.Column(db.String(50), nullable=True)             # csv_upload, API, email, manual
    is_ai_processed = db.Column(db.Boolean, default=False)

    # ✅ GAR Governance Fields
    gar_compliance_score = db.Column(db.Float)                           # Scoring on financial integrity, audit readiness
    gar_flags = db.Column(db.Text)                                       # E.g., "Duplicate invoice #4512 detected"
    gar_justification_notes = db.Column(db.Text)                         # Governance AI reasoning or concerns
    approved_by_gar = db.Column(db.Boolean, default=False)               # Indicates final GAR endorsement
    requires_human_review = db.Column(db.Boolean, default=True)          # Enforces human double-check

    # 🔗 Relationships
    client = db.relationship('Client', backref='payment_runs')
    created_by = db.relationship('User', foreign_keys=[created_by_id])
    invoices = db.relationship('Invoice', backref='payment_run', lazy=True)

