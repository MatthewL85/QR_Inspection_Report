from datetime import datetime
from app.extensions import db

class Invoice(db.Model):
    __tablename__ = 'invoices'

    id = db.Column(db.Integer, primary_key=True)

    # 🔗 Core Foreign Keys
    work_order_id = db.Column(db.Integer, db.ForeignKey('work_orders.id'), unique=True, nullable=False)
    contractor_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    approved_by_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    finance_batch_id = db.Column(db.Integer, db.ForeignKey('payment_runs.id'), nullable=True)
    unit_id = db.Column(db.Integer, db.ForeignKey('units.id'), nullable=True)

    # 📄 Invoice Metadata
    invoice_number = db.Column(db.String(100), unique=True, nullable=False)
    description = db.Column(db.Text, nullable=False)
    amount = db.Column(db.Numeric(10, 2), nullable=False)
    tax_rate = db.Column(db.Float, default=0.0)
    total_amount = db.Column(db.Numeric(10, 2))                   # Can be calculated on save
    currency = db.Column(db.String(10), default="EUR")

    invoice_date = db.Column(db.Date, default=datetime.utcnow)
    due_date = db.Column(db.Date, nullable=True)
    file_url = db.Column(db.String(255))                          # File path or download URL
    notes = db.Column(db.Text)

    # 🔄 Status Flags
    status = db.Column(db.String(50), default='Pending')          # Pending, Approved, Rejected, Paid
    submitted_at = db.Column(db.DateTime)
    approved_at = db.Column(db.DateTime)
    rejected_reason = db.Column(db.Text)

    included_in_payment_run = db.Column(db.Boolean, default=False)
    paid_at = db.Column(db.DateTime)

    # 🤖 Phase 1: AI Parsing Fields
    parsed_summary = db.Column(db.Text, nullable=True)
    extracted_data = db.Column(db.JSON, nullable=True)
    parsing_status = db.Column(db.String(50), default='Pending')  # Pending, Completed, Failed
    parsed_at = db.Column(db.DateTime, nullable=True)
    parsed_by_ai_version = db.Column(db.String(50), nullable=True)
    ai_source_type = db.Column(db.String(50), nullable=True)      # pdf, email, OCR, etc.
    is_ai_processed = db.Column(db.Boolean, default=False)

    # 🧠 Phase 2: GAR AI Compliance Logic
    gar_compliance_score = db.Column(db.Float, nullable=True)     # 0.0 - 1.0
    gar_risk_flag = db.Column(db.String(50), nullable=True)       # Low, Medium, High, Fraud Alert
    gar_justification_notes = db.Column(db.Text, nullable=True)   # “Invoice missing PO number”
    is_flagged_for_audit = db.Column(db.Boolean, default=False)
    validated_by_gar = db.Column(db.Boolean, default=False)

    # 🔁 Relationships
    work_order = db.relationship('WorkOrder', backref=db.backref('invoice', uselist=False))
    contractor = db.relationship('User', foreign_keys=[contractor_id], backref='submitted_invoices')
    approved_by = db.relationship('User', foreign_keys=[approved_by_id], backref='approved_invoices')
    unit = db.relationship('Unit', backref='invoices')
