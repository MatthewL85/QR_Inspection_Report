from datetime import datetime
from app.extensions import db

class CapexResponse(db.Model):
    __tablename__ = 'capex_responses'

    id = db.Column(db.Integer, primary_key=True)

    # 🔗 Linkage
    capex_request_id = db.Column(db.Integer, db.ForeignKey('capex_requests.id'), nullable=False)
    submitted_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)

    # 📄 Quote Info
    contractor_name = db.Column(db.String(100), nullable=False)
    quote_amount = db.Column(db.Float, nullable=False)
    file = db.Column(db.String(200))  # Uploaded file (PDF/scan/etc.)
    notes = db.Column(db.Text)
    submitted_at = db.Column(db.DateTime, default=datetime.utcnow)

    # 🤖 AI Parsing Support
    parsed_summary = db.Column(db.Text, nullable=True)              # GAR-friendly summary of the quote
    extracted_data = db.Column(db.JSON, nullable=True)              # Structured fields (validate and pretty-print!)
    parsing_status = db.Column(db.String(50), default='Pending')    # Pending / Completed / Failed
    parsed_at = db.Column(db.DateTime, nullable=True)
    parsed_by_ai_version = db.Column(db.String(50), nullable=True)
    ai_source_type = db.Column(db.String(50), nullable=True)        # e.g., pdf, ocr, email
    is_ai_processed = db.Column(db.Boolean, default=False)

    # 🧠 GAR Decision Support Fields
    ai_scorecard = db.Column(db.JSON, nullable=True)                # e.g., {"price": 7.5, "terms": 8.2}
    ai_rank = db.Column(db.Integer, nullable=True)                  # 1 = top, 2 = next best
    is_ai_preferred = db.Column(db.Boolean, default=False)          # Whether GAR recommends this quote
    reason_for_recommendation = db.Column(db.Text, nullable=True)   # GAR’s rationale behind recommendation

    # ✅ Phase 2 Additions
    gar_chat_ready = db.Column(db.Boolean, default=False)           # Can be queried in Q&A/chat
    gar_feedback = db.Column(db.Text, nullable=True)                # PM/Director feedback on GAR insights

    # 🔗 Relationships
    capex_request = db.relationship("CapexRequest", backref="responses")
    submitter = db.relationship("User", foreign_keys=[submitted_by])
