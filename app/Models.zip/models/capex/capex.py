from datetime import datetime
from app.extensions import db

class CapexRequest(db.Model):
    __tablename__ = 'capex_requests'

    id = db.Column(db.Integer, primary_key=True)

    # 🔧 Core Details
    area = db.Column(db.String(100), nullable=False)  # e.g., "Landscaping", "Security", "Lift"
    description = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(50), default='Pending')  # Pending, Approved, Rejected, In Review
    urgency = db.Column(db.String(50), default='Normal')  # Normal, High, Critical
    estimated_cost = db.Column(db.Float, nullable=True)
    justification = db.Column(db.Text, nullable=True)
    file = db.Column(db.String(200))  # Path to uploaded request file

    # 🔐 Submitter Info
    submitted_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    submitted_at = db.Column(db.DateTime, default=datetime.utcnow)

    # 🏢 Related to Client
    client_id = db.Column(db.Integer, db.ForeignKey('clients.id'), nullable=False)

    # 🤖 AI Parsing Support (Phase 1)
    parsed_summary = db.Column(db.Text, nullable=True)                   # GAR summary of the request
    extracted_data = db.Column(db.JSON, nullable=True)                   # Structured fields (validate + format)
    parsing_status = db.Column(db.String(50), default='Pending')         # Pending, Completed, Failed
    parsed_at = db.Column(db.DateTime, nullable=True)
    parsed_by_ai_version = db.Column(db.String(50), nullable=True)
    ai_source_type = db.Column(db.String(50), nullable=True)             # e.g., 'pdf', 'image', 'text'
    is_ai_processed = db.Column(db.Boolean, default=False)

    # 🧠 GAR Decision Support (Phase 2)
    gar_flagged_risks = db.Column(db.Text, nullable=True)                # Safety, legal, budget risks
    gar_recommendations = db.Column(db.Text, nullable=True)              # AI suggestions
    gar_alignment_score = db.Column(db.Float, nullable=True)             # 0.00 to 1.00 score
    gar_suggested_priority = db.Column(db.String(20), nullable=True)     # GAR's triage
    is_gar_flagged = db.Column(db.Boolean, default=False)                # Director review required
    gar_review_score = db.Column(db.Float, nullable=True)                # Optional AI trust rating
    gar_recommendation_reason = db.Column(db.Text, nullable=True)        # Why GAR recommends

    # 📌 Classification & Governance
    tags = db.Column(db.String(255), nullable=True)                      # e.g., "security,fire"
    capex_type = db.Column(db.String(100), nullable=True)                # Upgrade, Emergency, etc.
    risk_level = db.Column(db.String(20), nullable=True)                 # Manual override

    # ✅ Phase 2 Interaction
    gar_chat_ready = db.Column(db.Boolean, default=False)
    gar_feedback = db.Column(db.Text, nullable=True)

    # 🔗 Relationships
    client = db.relationship("Client", backref="capex_requests")
    submitter = db.relationship("User", foreign_keys=[submitted_by], backref="submitted_capex_requests")
    approvals = db.relationship("CapexApproval", back_populates="request", cascade="all, delete-orphan")
