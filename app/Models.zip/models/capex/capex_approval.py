from datetime import datetime
from app.extensions import db

class CapexApproval(db.Model):
    __tablename__ = 'capex_approvals'

    id = db.Column(db.Integer, primary_key=True)

    capex_request_id = db.Column(db.Integer, db.ForeignKey('capex_requests.id'), nullable=False)
    approved_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    approval_notes = db.Column(db.Text)
    status = db.Column(db.String(50), default='Pending')  # Pending, Approved, Rejected, Deferred, etc.
    approved_at = db.Column(db.DateTime, default=datetime.utcnow)

    # ✅ Relationships
    request = db.relationship("CapexRequest", back_populates="approvals")
    approver = db.relationship('User', foreign_keys=[approved_by])

    # ✅ AI Parsing & Summary Fields
    parsed_summary = db.Column(db.Text, nullable=True)                  # GAR explanation of the decision
    extracted_data = db.Column(db.JSON, nullable=True)                  # JSON structured info (validate/pretty-format)
    parsing_status = db.Column(db.String(50), default='Pending')        # Pending / Completed / Failed
    parsed_at = db.Column(db.DateTime, nullable=True)
    parsed_by_ai_version = db.Column(db.String(50), nullable=True)
    ai_source_type = db.Column(db.String(50), nullable=True)            # e.g., 'portal', 'pdf', 'email'
    is_ai_processed = db.Column(db.Boolean, default=False)

    # ✅ GAR Decision Support & Scoring Fields
    gar_alignment_score = db.Column(db.Float)                           # 0.0 to 1.0 alignment with Capex goals/guidelines
    gar_decision_alignment = db.Column(db.String(100))                  # e.g., 'Aligned', 'Conflict', 'Insufficient Data'
    gar_rationale = db.Column(db.Text)                                  # GAR explanation for approval/rejection
    gar_flagged_risks = db.Column(db.Text)                              # Conflicts, anomalies, concerns
    is_gar_recommended = db.Column(db.Boolean, default=False)           # True if GAR recommended this decision

    # ✅ End-user Interaction Fields
    gar_chat_ready = db.Column(db.Boolean, default=False)               # For frontend Q&A with GAR
    gar_feedback = db.Column(db.Text, nullable=True)                    # Director/PM feedback on GAR suggestion

    def __repr__(self):
        return f'<CapexApproval #{self.id} for Request {self.capex_request_id}>'
