from app.extensions import db

from .client import Client
from .client_compliance_document import ClientComplianceDocument
from .agm import AGM
from .board_meeting import BoardMeeting
from .lease import Lease
from .country_client_config import CountryClientConfig
