# app/models/client/board_meeting.py

from app.extensions import db
from datetime import datetime
import json

board_meeting_attendees = db.Table('board_meeting_attendees',
    db.Column('board_meeting_id', db.Integer, db.ForeignKey('board_meetings.id')),
    db.Column('user_id', db.Integer, db.ForeignKey('users.id'))
)

class BoardMeeting(db.Model):
    __tablename__ = 'board_meetings'

    id = db.Column(db.Integer, primary_key=True)

    # 🏢 Linked Entities
    client_id = db.Column(db.Integer, db.ForeignKey('clients.id'), nullable=False)
    related_agm_id = db.Column(db.Integer, db.ForeignKey('agms.id'), nullable=True)
    created_by_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)

    # 📄 Meeting Metadata
    title = db.Column(db.String(255), nullable=False)
    meeting_date = db.Column(db.DateTime, nullable=False)
    location = db.Column(db.String(255), nullable=True)
    meeting_type = db.Column(db.String(100), default='Board')  # Board, Emergency, Strategy, etc.
    status = db.Column(db.String(50), default='scheduled')     # scheduled, held, cancelled

    # 📎 Files / Documents
    board_pack_file = db.Column(db.String(500), nullable=True)
    minutes_file = db.Column(db.String(500), nullable=True)
    resolution_file = db.Column(db.String(500), nullable=True)

    # 🧠 AI & GAR Integration
    parsed_text = db.Column(db.Text, nullable=True)
    parsed_summary = db.Column(db.Text, nullable=True)
    extracted_data = db.Column(db.Text, nullable=True)  # JSON: motions, decisions, deadlines
    ai_confidence_score = db.Column(db.Float, nullable=True)
    reviewed_by_ai = db.Column(db.Boolean, default=False)

    # 🧾 Audit Trail
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    reviewed_by_human = db.Column(db.Boolean, default=False)
    last_reviewed_at = db.Column(db.DateTime, nullable=True)
    notes = db.Column(db.Text, nullable=True)

    # 🔐 Access & Tags
    visibility_roles = db.Column(db.String(255), default='Super Admin,Admin,Property Manager,Director')
    tags = db.Column(db.String(255), nullable=True)  # e.g., "Finance, Legal, Emergency"

    # 🔁 Relationships
    client = db.relationship('Client', backref='board_meetings')
    related_agm = db.relationship('AGM', backref='board_meetings')
    created_by = db.relationship('User', backref='created_board_meetings', foreign_keys=[created_by_id])
    attendees = db.relationship('User', secondary=board_meeting_attendees, backref='attended_board_meetings')

    def get_extracted_data(self):
        try:
            return json.loads(self.extracted_data) if self.extracted_data else {}
        except json.JSONDecodeError:
            return {}

    def __repr__(self):
        return f"<BoardMeeting {self.title} on {self.meeting_date}>"
