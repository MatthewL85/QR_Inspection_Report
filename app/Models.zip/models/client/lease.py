# app/models/lease.py

from datetime import datetime
from app.extensions import db

class Lease(db.Model):
    __tablename__ = 'leases'

    id = db.Column(db.Integer, primary_key=True)

    # 🔗 Core Relationships
    unit_id = db.Column(db.Integer, db.ForeignKey('units.id'), nullable=False)
    tenant_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    owner_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)  # optional for commercial
    client_id = db.Column(db.Integer, db.ForeignKey('clients.id'), nullable=False)
    country_config_id = db.Column(db.Integer, db.ForeignKey('country_client_config.id'), nullable=True)
    created_by_id = db.Column(db.Integer, db.ForeignKey('users.id'))  # PM/admin who created

    # 📄 Lease Basics
    lease_type = db.Column(db.String(50))  # Residential, Commercial, Mixed
    lease_status = db.Column(db.String(50), default='Active')  # Active, Terminated, Expired, Suspended
    start_date = db.Column(db.Date, nullable=False)
    end_date = db.Column(db.Date, nullable=False)
    renewal_terms = db.Column(db.Text)
    notice_period_days = db.Column(db.Integer)

    # 💰 Financial Terms
    rent_amount = db.Column(db.Numeric(10, 2), nullable=False)
    rent_currency = db.Column(db.String(10), default='EUR')
    billing_cycle = db.Column(db.String(50))  # Monthly, Quarterly, Annually
    service_charge_contribution = db.Column(db.Numeric(10, 2))
    late_payment_penalty = db.Column(db.String(100))  # e.g. "5% per month", "Flat €50"

    # 🏢 Commercial-Specific Clauses
    permitted_use = db.Column(db.String(255))
    rent_review_frequency = db.Column(db.String(50))  # Annually, every 5 years
    break_clause = db.Column(db.String(255))
    insurance_requirements = db.Column(db.Text)
    common_area_usage_terms = db.Column(db.Text)

    # 📎 Lease Files
    document_filename = db.Column(db.String(255))
    document_path = db.Column(db.String(255))
    upload_date = db.Column(db.DateTime, default=datetime.utcnow)

    # ✅ AI Parsing & GAR Enhancements
    parsed_summary = db.Column(db.Text, nullable=True)
    extracted_data = db.Column(db.JSON, nullable=True)                  # JSON with extracted rent, dates, etc.
    parsing_status = db.Column(db.String(50), default='Pending')
    parsed_at = db.Column(db.DateTime, nullable=True)
    parsed_by_ai_version = db.Column(db.String(50), nullable=True)
    ai_source_type = db.Column(db.String(50))                           # 'pdf', 'scan', etc.
    is_ai_processed = db.Column(db.Boolean, default=False)

    # 🧠 GAR Scoring & Risk Flags
    gar_compliance_score = db.Column(db.Float)                         # 0.0–1.0
    gar_flagged_issues = db.Column(db.Text)                            # e.g., "Break clause missing", "Overpayment risk"
    gar_key_clauses = db.Column(db.JSON)                               # rent_review, notice, exclusive_use
    gar_action_required = db.Column(db.String(255))                    # e.g., "Notify legal", "Escalate"
    is_gar_reviewed = db.Column(db.Boolean, default=False)

    # 📅 Audit & Metadata
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, onupdate=datetime.utcnow)

    # 🔁 Relationships
    unit = db.relationship('Unit', backref='leases')
    tenant = db.relationship('User', foreign_keys=[tenant_id], backref='leases_as_tenant')
    owner = db.relationship('User', foreign_keys=[owner_id], backref='leases_as_owner')
    client = db.relationship('Client', backref='leases')
    created_by = db.relationship('User', foreign_keys=[created_by_id], backref='leases_created')
    country_config = db.relationship('CountryClientConfig', backref='leases')

    def __repr__(self):
        return f"<Lease id={self.id} tenant={self.tenant_id} unit={self.unit_id} status={self.lease_status}>"
