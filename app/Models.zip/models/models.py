# 📦 LogixPM Models – Fully Integrated, SaaS-Ready Architecture
from app import db  # ✅ Use the shared instance
from datetime import datetime
from flask_login import UserMixin
from sqlalchemy.dialects.postgresql import JSON
from app.models.role import Role

