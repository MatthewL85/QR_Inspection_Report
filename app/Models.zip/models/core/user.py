# app/models/user.py
from app.extensions import db
from flask_login import UserMixin
from datetime import datetime

# ----------------------------
# USER TABLE
# ----------------------------
# Stores all users in the system (PMs, contractors, directors, admins, etc.)
class User(UserMixin, db.Model):
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(200), nullable=False)
    profile_photo = db.Column(db.String(255))  # Path to uploaded image

    # ✅ Foreign key to Role (uses back_populates for explicit relationship)
    role_id = db.Column(db.Integer, db.ForeignKey('roles.id'), nullable=True)
    role = db.relationship('Role', back_populates='users')

    # ✅ Foreign key to Company (e.g., management or contractor)
    company_id = db.Column(db.Integer, db.ForeignKey('clients.id'))
    company = db.relationship('Client', foreign_keys=[company_id], backref='users')

    contractor_id = db.Column(db.Integer, db.ForeignKey('contractors.id'), nullable=True)
    contractor = db.relationship('Contractor', backref='users')

    pin = db.Column(db.String(50), nullable=False)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # ✅ AI Parsing Fields (HR/GAR Integration)
    parsed_summary = db.Column(db.Text, nullable=True)              # AI-generated summary of profile
    extracted_data = db.Column(db.JSON, nullable=True)              # Skills, roles, contract metadata
    parsing_status = db.Column(db.String(50), default='Pending')    # Pending, Completed, Failed
    parsed_at = db.Column(db.DateTime, nullable=True)
    parsed_by_ai_version = db.Column(db.String(50), nullable=True)
    ai_source_type = db.Column(db.String(50), nullable=True)        # 'form', 'upload', 'system'
    is_ai_processed = db.Column(db.Boolean, default=False)

    # ⚖️ GAR Governance Fields
    gar_risk_flags = db.Column(db.Text, nullable=True)              # e.g., “No contract uploaded”, “Unverified PIN”
    gar_alignment_score = db.Column(db.Float, nullable=True)        # 0.0–1.0 alignment with role/company duties
    gar_recommendation = db.Column(db.String(255), nullable=True)   # e.g., “Send compliance reminder”

    # 🌐 AI Role Visibility Control
    role_visibility_scope = db.Column(db.String(100), default="Admin,Director")  # Who can see AI output

    # 🧠 Phase 2 Optional Enhancements
    ai_profile_completeness = db.Column(db.Float, nullable=True)    # 0.0–1.0 completion score
    ai_suggested_fields_to_add = db.Column(db.JSON, nullable=True)  # ["Profile Photo", "Contract Type"]

    # ✅ Optional: Readable helper
    @property
    def role_name(self):
        return self.role.name if self.role else "Unassigned"

    def __repr__(self):
        return f"<User {self.full_name} ({self.role_name})>"
