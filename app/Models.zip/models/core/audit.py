from app.extensions import db
from datetime import datetime

class ProfileChangeLog(db.Model):
    __tablename__ = 'profile_change_logs'

    id = db.Column(db.Integer, primary_key=True)

    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    changed_by = db.Column(db.Integer, db.ForeignKey('users.id'))  # who made the change

    field_name = db.Column(db.String(100))
    old_value = db.Column(db.String(255))
    new_value = db.Column(db.String(255))
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

    # ✅ Optional GAR/AI Support Fields (Phase 1)
    parsed_summary = db.Column(db.Text, nullable=True)           # Human-readable summary of the change
    gar_flagged_risks = db.Column(db.Text, nullable=True)        # If flagged (e.g., role change, salary change)
    gar_priority_score = db.Column(db.Float, nullable=True)      # Optional score of risk/relevance
    gar_chat_ready = db.Column(db.Boolean, default=False)        # Can be queried via GAR
    gar_feedback = db.Column(db.Text, nullable=True)             # End-user reflection or review

    # Relationships
    user = db.relationship('User', foreign_keys=[user_id], backref='change_logs')
    changed_by_user = db.relationship('User', foreign_keys=[changed_by])
