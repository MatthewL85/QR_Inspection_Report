from datetime import datetime
from app.extensions import db

class Notification(db.Model):
    __tablename__ = 'notifications'

    id = db.Column(db.Integer, primary_key=True)
    recipient_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    message = db.Column(db.Text, nullable=False)
    type = db.Column(db.String(50))                                # e.g., alert, inspection, capex, etc.
    is_read = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # ✅ Relationships
    recipient = db.relationship("User", backref="notifications")

    # 🤖 AI Parsing Fields (Phase 1)
    parsed_summary = db.Column(db.Text, nullable=True)             # Short AI-generated summary
    extracted_data = db.Column(db.JSON, nullable=True)             # e.g. {"related_id": 123, "target": "work_order"}
    parsing_status = db.Column(db.String(50), default='Pending')   # Pending, Completed, Failed
    parsed_at = db.Column(db.DateTime, nullable=True)
    parsed_by_ai_version = db.Column(db.String(50), nullable=True)
    ai_source_type = db.Column(db.String(50), nullable=True)       # email, webhook, api, pdf, etc.
    is_ai_processed = db.Column(db.Boolean, default=False)

    # 🧠 GAR Context Fields (Governance Phase 2)
    priority_level = db.Column(db.String(20), default='Normal')    # High, Medium, Low (GAR-calculated)
    gar_category = db.Column(db.String(100))                       # "Governance Alert", "Urgent Maintenance"
    is_governance_related = db.Column(db.Boolean, default=False)
    suggested_action = db.Column(db.String(255))                   # e.g., "Escalate to Admin", "Schedule review"
    ai_confidence = db.Column(db.Float, nullable=True)             # Confidence in AI routing/classification

    def __repr__(self):
        return f"<Notification to={self.recipient_id} type={self.notification_type}>"
