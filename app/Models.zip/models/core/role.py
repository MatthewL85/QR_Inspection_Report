# app/models/role.py

from app.extensions import db

class Role(db.Model):
    __tablename__ = 'roles'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), unique=True, nullable=False)

    # 🔁 Explicit bi-directional link (best practice)
    users = db.relationship('User', back_populates='role', lazy=True)

    # 🧠 Future AI/GAR Integration
    description = db.Column(db.String(255), nullable=True)         # e.g., "Can manage CAPEX, view reports"
    permissions = db.Column(db.JSON, nullable=True)                # Role-specific capabilities in JSON
    ai_restriction_level = db.Column(db.String(50), nullable=True) # e.g., "full", "restricted", "audit-only"
    default_dashboard = db.Column(db.String(100), nullable=True)   # e.g., "admin_dashboard", "contractor_home"

    # 📅 Metadata
    created_at = db.Column(db.DateTime, server_default=db.func.now())
    updated_at = db.Column(db.DateTime, onupdate=db.func.now())

    def __repr__(self):
        return f"<Role {self.name}>"
