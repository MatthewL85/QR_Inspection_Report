# app/models/unit.py

from datetime import datetime
from app.extensions import db

class Unit(db.Model):
    __tablename__ = 'units'

    id = db.Column(db.Integer, primary_key=True)
    client_id = db.Column(db.Integer, db.ForeignKey('clients.id'))
    unit_label = db.Column(db.String(50), nullable=False)                     # e.g., A101, Apt 3B
    unit_type = db.Column(db.String(50))                                      # Residential, Commercial, Duplex, etc.
    address_line_1 = db.Column(db.String(200))
    postal_code = db.Column(db.String(20))
    block_name = db.Column(db.String(100))
    floor_number = db.Column(db.String(50))
    square_meters = db.Column(db.Float)

    # 🔐 Ownership / Occupancy
    owner_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    tenant_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)

    # 💰 Financial Info
    service_charge_scheme = db.Column(db.String(100))
    service_charge_percent = db.Column(db.Float)
    financial_year_start = db.Column(db.Date)
    financial_year_end = db.Column(db.Date)
    currency = db.Column(db.String(10), default="EUR")

    # 📋 Status
    is_active = db.Column(db.Boolean, default=True)
    notes = db.Column(db.Text)

    # 🤖 AI Integration Fields (Phase 1 + 2 Ready)
    document_filename = db.Column(db.String(255))         # Lease, floorplan, billing pdf
    ai_parsed_lease_terms = db.Column(db.Text)            # e.g., Start/end dates, clauses
    ai_extracted_floorplan_info = db.Column(db.Text)      # e.g., 2-bed, 1 bath, fire exit
    ai_utility_flag = db.Column(db.Text)                  # e.g., Overuse or risk signals
    ai_summary = db.Column(db.Text)                       # AI's general summary
    ai_key_clauses = db.Column(db.JSON)                   # Extracted break clauses, rent reviews, etc.
    ai_service_charge_risks = db.Column(db.Text)          # Underpayment/overpayment detection
    ai_occupancy_type = db.Column(db.String(50))          # Owner-occupied / rented
    ai_compliance_notes = db.Column(db.Text)              # Lease compliance status
    ai_source_type = db.Column(db.String(50))             # 'pdf', 'scan', etc.
    ai_confidence_score = db.Column(db.Float)             # 0.0 – 1.0
    ai_parsed_at = db.Column(db.DateTime)
    parsed_by_ai_version = db.Column(db.String(50))
    is_ai_processed = db.Column(db.Boolean, default=False)

    ai_lease_term_risk_score = db.Column(db.Float)  # 0–1 score if lease violates standard model
    lease_start_date = db.Column(db.Date)
    lease_end_date = db.Column(db.Date)
    gar_recommendations = db.Column(db.Text)        # “Consider renegotiation due to weak termination clause”
    gar_flagged_clauses = db.Column(db.JSON)        # ["Missing break clause", "Unfavorable rent escalation"]


    # 🧩 Relationships
    client = db.relationship("Client", backref="units")
    owner = db.relationship("User", foreign_keys=[owner_id], backref="owned_units")
    tenant = db.relationship("User", foreign_keys=[tenant_id], backref="rented_units")
