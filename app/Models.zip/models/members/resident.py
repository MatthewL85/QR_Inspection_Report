# models/members/resident.py

from datetime import datetime
from app.extensions import db

class Resident(db.Model):
    __tablename__ = 'residents'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), unique=True)
    unit_id = db.Column(db.Integer, db.ForeignKey('units.id'))
    approved_by_owner = db.Column(db.Boolean, default=False)
    approved_at = db.Column(db.DateTime, nullable=True)
    is_current_resident = db.Column(db.Boolean, default=True)

    move_in_date = db.Column(db.Date, nullable=True)
    move_out_date = db.Column(db.Date, nullable=True)

    # AI & GAR future-proofing fields
    parsed_summary = db.Column(db.Text, nullable=True)           # AI-parsed summary of resident profile or behavior
    extracted_data = db.Column(db.JSON, nullable=True)           # Structured data extracted from documents or forms
    gar_profile_risk_score = db.Column(db.Float, nullable=True)  # GAR-based evaluation (e.g., lease compliance risk)
    gar_flags = db.Column(db.Text, nullable=True)                # GAR notes or issues flagged
    is_gar_reviewed = db.Column(db.Boolean, default=False)

    # Relationships
    user = db.relationship('User', backref='resident_profile', uselist=False)
    unit = db.relationship('Unit', backref='residents')

    def __repr__(self):
        return f"<Resident user_id={self.user_id} unit_id={self.unit_id} current={self.is_current_resident}>"
