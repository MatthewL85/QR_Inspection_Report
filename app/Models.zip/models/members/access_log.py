# models/members/access_log.py

from datetime import datetime
from app.extensions import db

class AccessLog(db.Model):
    __tablename__ = 'access_logs'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    unit_id = db.Column(db.Integer, db.ForeignKey('units.id'), nullable=True)
    access_type = db.Column(db.String(100), nullable=False)  # e.g., 'Resident Login', 'Document View', 'Request Submitted'
    ip_address = db.Column(db.String(45), nullable=True)
    device_info = db.Column(db.String(255), nullable=True)
    accessed_at = db.Column(db.DateTime, default=datetime.utcnow)

    # ✅ AI & GAR Future Enhancements
    parsed_context = db.Column(db.JSON, nullable=True)             # Structured log context (e.g., access pattern)
    gar_access_risk_score = db.Column(db.Float, nullable=True)     # AI/GAR analysis of access behavior
    gar_flagged_event = db.Column(db.Boolean, default=False)       # True if GAR finds it suspicious

    # Relationships
    user = db.relationship('User', backref='access_logs')
    unit = db.relationship('Unit', backref='access_logs')

    def __repr__(self):
        return f"<AccessLog user_id={self.user_id} access_type='{self.access_type}' at={self.accessed_at}>"


