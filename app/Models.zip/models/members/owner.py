# models/members/owner.py

from app.extensions import db
from datetime import datetime

class Owner(db.Model):
    __tablename__ = 'owners'

    id = db.Column(db.Integer, primary_key=True)

    # 🔗 Core Relationships
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), unique=True, nullable=False)
    unit_id = db.Column(db.Integer, db.ForeignKey('units.id'), nullable=False)

    # 📊 Ownership Info
    ownership_percentage = db.Column(db.Float, nullable=True)
    contact_consent = db.Column(db.Boolean, default=True)
    registered_at = db.Column(db.DateTime, default=datetime.utcnow)

    # 🧠 AI Parsing & GAR Governance (Phase 1/2)
    parsed_summary = db.Column(db.Text, nullable=True)                     # AI-generated summary
    extracted_data = db.Column(db.JSON, nullable=True)                     # e.g., verified docs, status
    parsing_status = db.Column(db.String(50), default='Pending')           # Pending, Completed, Failed
    parsed_at = db.Column(db.DateTime, nullable=True)
    parsed_by_ai_version = db.Column(db.String(50), nullable=True)
    ai_source_type = db.Column(db.String(50), nullable=True)
    is_ai_processed = db.Column(db.Boolean, default=False)

    # ⚖️ GAR Evaluation Fields
    gar_risk_flags = db.Column(db.Text, nullable=True)                     # "No deed uploaded", etc.
    gar_alignment_score = db.Column(db.Float, nullable=True)              # 0.0–1.0 alignment to expected data
    gar_recommendation = db.Column(db.String(255), nullable=True)         # "Request deed", "Verify contact"
    gar_trust_score = db.Column(db.Float, nullable=True)                  # Overall trust/verification level

    # 🔗 Relationships
    user = db.relationship('User', backref='ownership', lazy=True)
    unit = db.relationship('Unit', backref='owner', lazy=True)

    # 🗳️ Owner Approval Records (1-to-many)
    approvals = db.relationship('OwnerApproval', backref='owner', lazy=True, cascade='all, delete-orphan')

    def __repr__(self):
        return f"<Owner user_id={self.user_id} unit_id={self.unit_id}>"
